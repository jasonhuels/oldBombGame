package a6;

/**
 * Created by Jason Huels on 4/20/2016.
 */
public class GameMain {
    public static void main(String[] args) {
        Game g = new Game();
        g.play();
    }
}
